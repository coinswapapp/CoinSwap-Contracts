import chai, { expect } from 'chai'
import { Contract } from 'ethers'
import { AddressZero, Zero, MaxUint256 } from 'ethers/constants'
import { BigNumber, bigNumberify,keccak256 } from 'ethers/utils'
import { solidity, MockProvider, createFixtureLoader } from 'ethereum-waffle'
import { ecsign } from 'ethereumjs-util'

import { expandTo18Decimals, getApprovalDigest, mineBlock, MINIMUM_LIQUIDITY } from './shared/utilities'
import { v2Fixture } from './shared/fixtures'
import unipair from '../node_modules/@uniswap/v2-core/build/UniswapV2Pair.json'

chai.use(solidity)
let gas0 : BigNumber, gas1 : BigNumber, gas2 : BigNumber, gas3 : BigNumber, gas4 : BigNumber, gas5 : BigNumber, gas6 : BigNumber, gas7 : BigNumber

const overrides = {
  gasLimit: 9999999
}

enum RouterVersion {
  UniswapV2Router02 = 'UniswapV2Router02'
}

describe('GAS testing', () => {
  for (const routerVersion of Object.keys(RouterVersion)) {
    const provider = new MockProvider({
      hardfork: 'istanbul',
      mnemonic: 'horn horn horn horn horn horn horn horn horn horn horn horn',
      gasLimit: 9999999
    })
    const [wallet] = provider.getWallets()
    const loadFixture = createFixtureLoader(provider, [wallet])

    let token0: Contract
    let token1: Contract
    let WETH: Contract
    let WETHPartner: Contract
    let factory: Contract
    let router: Contract
    let pair: Contract
    let WETHPair: Contract
    let routerEventEmitter: Contract
    beforeEach(async function() {
      const fixture = await loadFixture(v2Fixture)
      token0 = fixture.token0
      token1 = fixture.token1
      WETH = fixture.WETH
      WETHPartner = fixture.WETHPartner
      factory = fixture.factoryV2
      router = {
        [RouterVersion.UniswapV2Router02]: fixture.router02
      }[routerVersion as RouterVersion]
      pair = fixture.pair
      WETHPair = fixture.WETHPair
      routerEventEmitter = fixture.routerEventEmitter
    })

    afterEach(async function() {
      expect(await provider.getBalance(router.address)).to.eq(Zero)
    })

    describe(routerVersion, () => {
      it('addLiquidity gas', async () => {
        const token0Amount = expandTo18Decimals(40000000)
        const token1Amount = expandTo18Decimals(10000000)

        const expectedLiquidity = expandTo18Decimals(2)
        await token0.approve(router.address, MaxUint256)
        await token1.approve(router.address, MaxUint256)
        const tx = await router.addLiquidity(
            token0.address,
            token1.address,
            token0Amount,
            token1Amount,
            0,
            0,
            wallet.address,
            MaxUint256,
            overrides
          )
        const receipt = await tx.wait()
        gas1 = receipt.gasUsed
      })

      it('addLiquidityETH gas', async () => {
        const WETHPartnerAmount = expandTo18Decimals(40000000)
        const ETHAmount = expandTo18Decimals(10000000)

        const expectedLiquidity = expandTo18Decimals(20000000)
        const WETHPairToken0 = await WETHPair.token0()
        await WETHPartner.approve(router.address, MaxUint256)
        const tx = await router.addLiquidityETH(
            WETHPartner.address,
            WETHPartnerAmount,
            WETHPartnerAmount,
            ETHAmount,
            wallet.address,
            MaxUint256,
            { ...overrides, value: ETHAmount }
          )
          const receipt = await tx.wait()
          gas2 = receipt.gasUsed
      })

      async function addLiquidity(token0Amount: BigNumber, token1Amount: BigNumber) {
        await token0.transfer(pair.address, token0Amount)
        await token1.transfer(pair.address, token1Amount)
        const tx = await pair.mint(wallet.address, overrides)
        const receipt = await tx.wait()
        gas0 = receipt.gasUsed
      }
      
      it('removeLiquidity', async () => {
        const token0Amount = expandTo18Decimals(40000000)
        const token1Amount = expandTo18Decimals(10000000)
        await addLiquidity(token0Amount, token1Amount)

        const expectedLiquidity = expandTo18Decimals(20000000)
        await pair.approve(router.address, MaxUint256)
        const tx = await router.removeLiquidity(
            token0.address,
            token1.address,
            expectedLiquidity.sub(MINIMUM_LIQUIDITY),
            0,
            0,
            wallet.address,
            MaxUint256,
            overrides
          )
          const receipt = await tx.wait()
          gas3= receipt.gasUsed
      })

      it('full removeLiquidityETH', async () => {
        const WETHPartnerAmount = expandTo18Decimals(40000000)
        const ETHAmount = expandTo18Decimals(10000000)
        await WETHPartner.transfer(WETHPair.address, WETHPartnerAmount)
        await WETH.deposit({ value: ETHAmount })
        await WETH.transfer(WETHPair.address, ETHAmount)
        await WETHPair.mint(wallet.address, overrides)

        const expectedLiquidity = expandTo18Decimals(20000000)
        const WETHPairToken0 = await WETHPair.token0()
        await WETHPair.approve(router.address, MaxUint256)
        const tx = await router.removeLiquidityETH(
            WETHPartner.address,
            expectedLiquidity.sub(MINIMUM_LIQUIDITY),
            0,
            0,
            wallet.address,
            MaxUint256,
            overrides
          )
          const receipt = await tx.wait()
          gas4 = receipt.gasUsed
      })

      it('removeLiquidityETH', async () => {
        const WETHPartnerAmount = expandTo18Decimals(40000000)
        const ETHAmount = expandTo18Decimals(10000000)
        await WETHPartner.transfer(WETHPair.address, WETHPartnerAmount)
        await WETH.deposit({ value: ETHAmount })
        await WETH.transfer(WETHPair.address, ETHAmount)
        await WETHPair.mint(wallet.address, overrides)

        const expectedLiquidity = expandTo18Decimals(10000000)
        const WETHPairToken0 = await WETHPair.token0()
        await WETHPair.approve(router.address, MaxUint256)
        const tx = await router.removeLiquidityETH(
            WETHPartner.address,
            expectedLiquidity.sub(MINIMUM_LIQUIDITY),
            0,
            0,
            wallet.address,
            MaxUint256,
            overrides
          )
          const receipt = await tx.wait()
          gas5 = receipt.gasUsed
      })

      describe('swapExactTokensForTokens', () => {
        const token0Amount = expandTo18Decimals(40000000)
        const token1Amount = expandTo18Decimals(10000000)
        const swapAmount = expandTo18Decimals(1000)

        beforeEach(async () => {
          await addLiquidity(token0Amount, token1Amount)
          await token0.approve(router.address, MaxUint256)
        })

        it('happy path', async () => {
          const tx = await router.swapExactTokensForTokens(
              swapAmount,
              0,
              [token0.address, token1.address],
              wallet.address,
              MaxUint256,
              overrides
            )
            const receipt = await tx.wait()
            gas6 = receipt.gasUsed
        })

        it('gas', async () => {
          // ensure that setting price{0,1}CumulativeLast for the first time doesn't affect our gas math
          await mineBlock(provider, (await provider.getBlock('latest')).timestamp + 1)
          await pair.sync(overrides)

          await token0.approve(router.address, MaxUint256)
          await mineBlock(provider, (await provider.getBlock('latest')).timestamp + 1)
          const tx = await router.swapExactTokensForTokens(
            swapAmount,
            0,
            [token0.address, token1.address],
            wallet.address,
            MaxUint256,
            overrides
          )
          const receipt = await tx.wait()
          gas7=receipt.gasUsed
        })
        it('gas output', async () => {          
              console.log("GAS TESTING OUTPUT:")
              console.log("Pair.mine():"+gas0)
              console.log("router.AddLiquidity:"+gas1)
              console.log("router.addLiquidityETH:"+gas2)
              console.log("router.removeLiquidity:"+gas3)
              console.log("router.removeLiquidityETH (partial):"+gas4)
              console.log("router.removeLiquidityETH (full):"+gas5)
              console.log("router.swapExactTokensForTokens:"+gas6)
              console.log("router.swapExactTokensForTokens:"+gas7)
            })
      })
    })
  }
})

   
